import AdminDashboard from '@/react-app/pages/AdminDashboard';

export default function Page() {
  return <AdminDashboard />;
}

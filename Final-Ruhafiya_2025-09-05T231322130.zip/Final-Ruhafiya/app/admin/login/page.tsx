import AdminLogin from '@/react-app/pages/AdminLogin';

export default function Page() {
  return <AdminLogin />;
}

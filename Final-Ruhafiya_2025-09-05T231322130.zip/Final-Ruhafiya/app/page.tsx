import Home from '../src/react-app/pages/Home';

export default function Page() {
  return <Home />;
}

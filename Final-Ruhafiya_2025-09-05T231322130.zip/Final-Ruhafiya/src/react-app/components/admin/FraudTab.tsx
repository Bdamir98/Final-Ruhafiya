// Placeholder component - FraudTab would be extracted from AdminDashboard
"use client";

interface FraudTabProps {
  [key: string]: any;
}

export default function FraudTab({}: FraudTabProps) {
  return <div>Fraud Detection Tab - To be implemented</div>;
}
import Home from '@/components/sections/Home';

export default function Page() {
  return <Home />;
}

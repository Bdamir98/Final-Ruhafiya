import AdminLogin from '@/components/admin/dashboard/AdminLogin';

export default function Page() {
  return <AdminLogin />;
}

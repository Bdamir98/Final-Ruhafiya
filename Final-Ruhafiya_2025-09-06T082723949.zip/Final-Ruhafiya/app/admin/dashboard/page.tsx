import AdminDashboard from '@/components/admin/dashboard/AdminDashboard';

export default function Page() {
  return <AdminDashboard />;
}
